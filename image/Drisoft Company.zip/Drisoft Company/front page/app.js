
let currentIndex = 1;
displaySlides();

function displaySlides(){
    let x;
    let slides = document.getElementsByClassName('item');
   
    for (x = 0; x < slides.length; x++) {
        slides[x].style.display = 'none';
        
    }currentIndex++;
    if(currentIndex > slides.length){
        currentIndex = 1;
    }
    slides[currentIndex - 1].style.display = 'block';
    setTimeout(displaySlides,3000)
}

const harmburger = document.querySelector('.hamburger')
const nav = document.querySelector('.nav-links')
harmburger.addEventListener('click', function(){
   nav.classList.toggle('none')
})